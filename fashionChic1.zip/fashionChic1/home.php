<?php include 'actions/sessions.php'; ?>
<?php include 'actions/connect_db.php'; ?>

<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="css/homeCss.css">
<title>Fashion Chic Online Shop</title>
</head>
<body>

<div class="grid-container">
  <div class="header">
    <ul>
      <li style="float: left;padding: 5px; color: white; font-size: 25px;"><a href="home.php"> Fashion Chic Online Shop</a></li>
      
       <li style="float: right;"><a href="actions/logout.php?logout">Logout</a></li>
        <li style="float: right;"><a href="#"><?=$userz?></a></li>
        <?php 
        $sselect = "SELECT COUNT(cart_id) as counts FROM tbl_cart WHERE user_id = '$userId' AND status = 0";
        $query = mysqli_query($connect, $sselect);
          $row = mysqli_fetch_assoc($query);
        ?>
         <li  style="float:right;"><a href="orders.php" >Orders</a></li>
        <li style="float: right;"><a href="cart.php">Cart (<?=$row['counts']?>)</a></li>
    </ul>

    <div class="titleHome">
      <h2>Fashion Chic Online Shop</h2>
    </div>
  </div>

  <div style="padding: 20px;">
      <h4>Products</h4>
      <div class="grid-container">
      <?php 
      $sql = "SELECT * FROM tbl_products";
      $query = mysqli_query($connect, $sql);
        while($row = $query->fetch_assoc()){ ?>

        <div class="grid-item">
          <img src="admin/images/<?=$row['photo']?>" width="200" height="250">
          <h3><?=$row['title']?></h3>
          <p><i><?=$row['description']?></i></p>
          <h2>P <?=$row['price']?>.00</h2><br>
         <a href="addToCartAction.php?id=<?=$row['prod_id']?>&userId=<?=$userId?>" class="btn" style="background:#ed7a14;">Add to Cart</a>
        </div>

      <?php  }?>
      </div>
      

  </div>

  <div class="footer">
  <p>© 2023 All Rights Reserved. By Fashion Chic</p>
  </div>
</div>

</body>
</html>

<?php 
if (isset($_GET['resp'])) {
  $msg = $_GET['resp'];
    if ($msg == 0) { ?>
      <script>alert('Added to Cart');</script>
    <?php }else if ($msg == 1) { ?>
      <script>alert('Failed!');</script>
   
    <?php }else if ($msg == 2) { ?>
      <script>alert('Success!');</script>
   
    <?php }else if ($msg == 3) { ?>
      <script>alert('Failed!');</script>
   
    <?php } } ?> 


