<?php
	include 'actions/connect_db.php';

	$userId = $_POST['userId'];
	$method = $_POST['method'];
	$name = $_POST['name'];
	$address = $_POST['address'];
	$prodID = $_POST['prodID'];
	$cartId = $_POST['cartId'];
	$expCart = explode(",", $cartId);
	$expProd = explode(",", $prodID);
	$status = 'For Approval';

	for ($i=0; $i < count($expProd); $i++) { 
		$insert = "INSERT INTO tbl_orders( user_id, prod_id, fullname, address, method, status) VALUES ('$userId','$expProd[$i]','$name','$address','$method','$status')";
		$query = mysqli_query($connect, $insert);

		$update = "UPDATE tbl_cart SET status=1 WHERE cart_id = '$expCart[$i]' ";
		$query1 = mysqli_query($connect, $update);
	}

	if ($query1 == 1) {
			header('location:home.php?resp=2');
		}else{
			header('location:home.php?resp=3');
		}
	




 ?>

