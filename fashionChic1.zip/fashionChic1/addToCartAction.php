<?php
	include 'actions/connect_db.php';

	$id = $_GET['id'];
	$userId = $_GET['userId'];

	$sql = "INSERT INTO tbl_cart (prod_id,user_id) VALUES ('$id','$userId')";
		$query = mysqli_query ($connect, $sql);

		if ($query == 1) {
			header('location:home.php?resp=0');
		}else{
			header('location:home.php?resp=1');
		}
?>