<?php include 'actions/sessions.php'; ?>
<?php include 'actions/connect_db.php'; ?>

<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="css/homeCss.css">
<title>Fashion Chic Online Shop</title>
</head>
<body>

<div class="grid-container">
  <div class="headerCart">
    <ul>
      <li style="float: left;padding: 5px; color: white; font-size: 25px;"><a href="home.php"> Fashion Chic Online Shop</a></li>
      
       <li style="float: right;"><a href="actions/logout.php?logout">Logout</a></li>
        <li style="float: right;"><a href="#"><?=$userz?></a></li>
        <?php 
        $sselect = "SELECT COUNT(cart_id) as counts FROM tbl_cart WHERE user_id = '$userId' AND status = 0";
        $query = mysqli_query($connect, $sselect);
          $row = mysqli_fetch_assoc($query);
        ?>
         <li  style="float:right;"><a href="orders.php" >Orders</a></li>
        <li style="float: right;"><a href="cart.php">Cart (<?=$row['counts']?>)</a></li>
    </ul>
  </div>

  <div class="mainCart">
    

    <div style="float:left; ">
      <h1>Cart</h1>
        <?php 
          $sql = "SELECT * FROM tbl_cart tc 
          JOIN tbl_products tp ON tc.prod_id = tp.prod_id 
          JOIN tbl_users tu ON tc.user_id = tu.userId 
          WHERE tc.user_id = '$userId' AND tc.status = 0";
          $query = mysqli_query($connect, $sql);
            while($row = $query->fetch_assoc()){ ?>
              <!-- <label for="cartItems<?=$row['cart_id']?>"> -->
                <div class="card">
                  <div style="float: left;">
                    <img src="admin/images/<?=$row['photo']?>" width="100" height="150"> 
                 </div>
                 <div style="float:left;width: 400px;padding: 20px;" >
                   <h3><?=$row['title']?></h3>
                   <p style="font-size:12px"><?=$row['description']?></p>

                   <br><br>
                   <h2>P <?=$row['price']?>.00</h2>
                 </div>
                </div>
             <!-- </label> -->
            <!-- <input type="checkbox" name="prods[]" id="cartItems<?=$row['cart_id']?>"> -->
        <?php } ?>
    </div>

    <div style="float:left;margin-left: 100px;">
      <h1>Check-out Details</h1><br>
      <h2>Item Summary</h2>
      <div style="float:right;width: 600px;padding: 20px;">
        <?php 
          $sql = "SELECT * FROM tbl_cart tc 
          JOIN tbl_products tp ON tc.prod_id = tp.prod_id 
          JOIN tbl_users tu ON tc.user_id = tu.userId 
          WHERE tc.user_id = '$userId' AND tc.status = 0";
          $query = mysqli_query($connect, $sql);
            while($row = $query->fetch_assoc()){ ?>

              <p> 1x <?=$row['title']?> @ P <?=$row['price']?>.00</p>
              

            <?php } ?>

          <?php  $sql = "SELECT tp.price as perPrice FROM tbl_cart tc 
          JOIN tbl_products tp ON tc.prod_id = tp.prod_id 
          JOIN tbl_users tu ON tc.user_id = tu.userId 
          WHERE tc.user_id = '$userId' AND tc.status = 0 ";
          $query = mysqli_query($connect, $sql); 
          $rowz = mysqli_fetch_assoc($query);
              
          ?>

          <?php  $sql = "SELECT tc.prod_id FROM tbl_cart tc 
          JOIN tbl_products tp ON tc.prod_id = tp.prod_id 
          JOIN tbl_users tu ON tc.user_id = tu.userId 
          WHERE tc.user_id = '$userId' AND tc.status = 0  ";
          $query = mysqli_query($connect, $sql); 
          while ($row = mysqli_fetch_assoc($query)) {
          $id_array1[] = $row["prod_id"];

          $prod_id = implode(",", $id_array1);
             }
          ?>

           <?php  $sql = "SELECT tc.cart_id FROM tbl_cart tc 
          JOIN tbl_products tp ON tc.prod_id = tp.prod_id 
          JOIN tbl_users tu ON tc.user_id = tu.userId 
          WHERE tc.user_id = '$userId' AND tc.status = 0  ";
          $query = mysqli_query($connect, $sql); 
          while ($row = mysqli_fetch_assoc($query)) {
          $id_array[] = $row["cart_id"];

          $cartId = implode(",", $id_array);
             }
          ?>
          <br>
          <br>
          
          <br>

          <form class="formDetails" action="checkOutAction.php" method="POST">
            <h1>Shipping Details</h1><br>
            <input type="hidden" name="userId" value="<?=$userId?>">
            <input type="hidden" name="cartId" value="<?=$cartId?>">
            <input type="hidden" name="prodID" value="<?=$prod_id?>">
            <input type="hidden" name="method" value="Cash on Delivery">
            <div>
              <label>Fullname</label><br>
              <input type="text" name="name">
            </div>

            <div>
              <label>Address</label><br>
              <input type="text" name="address">
            </div>

            <h4>Payment Method = Cash on Delivery</h4> <br>
            <button type="submit" name="submit" style="width:100px; height: 40px;background: orange;color: white;border: 0;cursor:pointer;">Check Out</button>

            
          </form>
      </div>
    </div>
      
  </div>

  <div class="footer">
    <p>© 2023 All Rights Reserved. By Fashion Chic</p>
  </div>

</div>
</body>
</html>

