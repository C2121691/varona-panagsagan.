<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Fashion Chic</title>
	<link rel="stylesheet" type="text/css" href="css/index_style.css">
</head>
<body >


	<div id="login-form-wrap">
		<h2>FASHION CHIC</h2>
	  <h4>Register</h4>
	  <form id="login-form" method="POST" action="actions/registerAction.php">
	    
	    <p>
	    <input type="email" id="email" name="email" placeholder="Email Address" required><i class="validation"><span></span><span></span></i>
	    </p>

	    <p>
	    <input type="password" id="password" name="password" placeholder="Password" required><i class="validation"><span></span><span></span></i>
	    </p>
	    <p>
	    <input type="submit" id="submit" value="Submit">
	    </p>
	  </form>
	  <div id="create-account-wrap">
	    <p>Already a member? Login <a href="index.php">here</a><p>
	  </div><!--create-account-wrap-->
	</div><!--login-form-wrap-->

</body>
</html>

<?php 
if (isset($_GET['resp'])) {
	$msg = $_GET['resp'];
		if ($msg == 0) { ?>
			<script>alert('Email Already Taken!');</script>
		<?php }else if ($msg == 1) { ?>
			<script>alert('Success!');</script>
		<?php }else if ($msg == 2) { ?>
			<script>alert('Error!');</script>
		<?php } } ?>