<?php include '../actions/sessions.php'; ?>
<?php include '../actions/connect_db.php'; ?>

<!DOCTYPE html>
<html>
  <head>
    <title>Dashboard  </title>
    <meta charset="utf-8">
    <meta name="robots" content="noindex">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.5">
    <link rel="stylesheet" href="css/styles.css">
  </head>
  <body>
    <!-- (A) SIDEBAR -->
    <div id="pgside">
      <!-- (A1) BRANDING OR USER -->
      <!-- LINK TO DASHBOARD OR LOGOUT -->
      <div id="pguser">
        <img src="css/userLogo.png">
        <i class="txt"><?=$userz?></i>
      </div>

      <!-- (A2) MENU ITEMS -->
      <a href="index.php" class="current">
        <i class="txt">Add Products</i>
      </a>
      <a href="products.php" class="">
        <i class="txt">Products</i>
      </a>
      <a href="orders.php">
        <i class="txt">Orders</i>
      </a>
    </div>

    <!-- (B) MAIN -->
    <main id="pgmain">
      <div style="height: 100px;">
        <h2 style="float:left">Add Products</h2>
         <a class="logoutBtn" href="../actions/logout.php?logout"><p>Logout</p></a>
      </div>
      
      <?php
      if(isset($_GET['id'])){
        $id = $_GET['id'];

        $sql = "SELECT * FROM tbl_products WHERE prod_id = '$id' ";
        $query = mysqli_query($connect, $sql);
        while($row = $query->fetch_assoc()){ ?>

          <div class="formDiv">
            <form class="formAddProd" method="post" action="editProductsAction.php" enctype="multipart/form-data">
              <input type="hidden" name="id" value="<?=$id?>">
              <div>
                <label>Title</label><br>
                <input type="text" name="title" value="<?=$row['title']?>">
              </div>

              <div>
                <label>Description</label><br>
                <input type="text" name="description" value="<?=$row['description']?>">
              </div>

              <div>
                <label>Price</label><br>
                <input type="text" name="price" value="<?=$row['price']?>">
              </div>  

              <center><button class="btnSubmit" type="submit" >Save</button></center>
            </form>
          </div>

      <?php  } } ?>

      
    </main>
  </body>
</html>

<?php 
if (isset($_GET['resp'])) {
  $msg = $_GET['resp'];
    if ($msg == 0) { ?>
      <script>alert('Success');</script>
    <?php }else if ($msg == 1) { ?>
      <script>alert('Failed!');</script>
   
    <?php } } ?>