<?php 
	include '../actions/connect_db.php';

	$title = $_POST['title'];
	$description = $_POST['description'];
	$price = $_POST['price'];
	$photo = $_POST['image'];

	$extension=array('jpeg','jpg','png','gif');
	foreach ($_FILES['image']['tmp_name'] as $key => $value) {
		$filename=$_FILES['image']['name'][$key];
		$filename_tmp=$_FILES['image']['tmp_name'][$key];
		echo '<br>';
		$ext=pathinfo($filename,PATHINFO_EXTENSION);

		$finalimg='';
		if(in_array($ext,$extension))
		{
			if(!file_exists('images/'.$filename))
			{
			move_uploaded_file($filename_tmp, 'images/'.$filename);
			$finalimg=$filename;
			}else
			{
				 $filename=str_replace('.','-',basename($filename,$ext));
				 $newfilename=$filename.time().".".$ext;
				 move_uploaded_file($filename_tmp, 'images/'.$newfilename);
				 $finalimg=$newfilename;
			}
			//insert

			$insert = "INSERT INTO `tbl_products`( `title`, `description`, `price`, `photo`) VALUES ('$title','$description','$price','$finalimg')";
			$query = mysqli_query($connect, $insert);

				if ($query == 1) {
					header('location:index.php?resp=0');
				}else{
					header('location:index.php?resp=1');
				}
			
		}else{
			header('location:index.php?resp=1');
			}
	}


	

?>