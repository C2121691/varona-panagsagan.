<?php include '../actions/sessions.php'; ?>
<?php include '../actions/connect_db.php'; ?>

<!DOCTYPE html>
<html>
  <head>
    <title>Dashboard  </title>
    <meta charset="utf-8">
    <meta name="robots" content="noindex">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.5">
    <link rel="stylesheet" href="css/styles.css">
  </head>
  <body>
    <!-- (A) SIDEBAR -->
    <div id="pgside">
      <!-- (A1) BRANDING OR USER -->
      <!-- LINK TO DASHBOARD OR LOGOUT -->
      <div id="pguser">
        <img src="css/userLogo.png">
        <i class="txt"><?=$userz?></i>
      </div>

      <!-- (A2) MENU ITEMS -->
      <a href="index.php" class="">
        <i class="txt">Add Products</i>
      </a>
      <a href="products.php" class="current">
        <i class="txt">Products</i>
      </a>
      <a href="orders.php">
        <i class="txt">Orders</i>
      </a>
      <a href="register-admin.php">
        <i class="txt">Add User</i>
      </a>
    </div>

    <!-- (B) MAIN -->
    <main id="pgmain">
      <h2 style="float:left">Products Table</h2>
      <a class="logoutBtn" href="../actions/logout.php?logout"><p>Logout</p></a>

      <div class="table">
          <table id="customers">
            <thead>
                <th>ID</th>
                <th>Title</th>
                <th>Description</th>
                <th>Price</th>
                <th>Photo</th>
                <th>Action</th>
            </thead>
            <tbody>
              <?php
              $sql = 'SELECT * FROM tbl_products';
              $query = mysqli_query($connect, $sql);
                while($row = $query->fetch_assoc()){ ?>
                  <tr>
                    <td><?=$row['prod_id']?></td>
                    <td><?=$row['title']?></td>
                    <td><?=$row['description']?></td>
                    <td><?=$row['price']?></td>
                    <td> <img src="images/<?=$row['photo']?>" width='100'> </td>
                    <td>
                      <a href="editProd.php?id=<?=$row['prod_id']?>" class="btn" style="background:green;" >Edit</a><br><br>
                      <a href="deleteProdAction.php?id=<?=$row['prod_id']?>" class="btn" style="background:red;">Delete</a>
                    </td>
                  </tr>
              <?php  } ?>
              
            </tbody>
          </table>
      </div>
    </main>
  </body>
</html>

<?php 
if (isset($_GET['resp'])) {
  $msg = $_GET['resp'];
    if ($msg == 0) { ?>
      <script>alert('Success');</script>
    <?php }else if ($msg == 1) { ?>
      <script>alert('Failed!');</script>
   
    <?php } } ?>