<?php
	include 'connect_dbms.php';
$email = $_POST['email'];
$password = $_POST['password'];
$hash = md5($password);

	$select = "SELECT * FROM tbl_users WHERE email = '$email' ";
	$selectQuery = mysqli_query($connect, $select);
		if (mysqli_num_rows($selectQuery)>0) {
			header('location: ../admin/register-admin.php?resp=0');
		}else{
			$insert = "INSERT INTO `tbl_users`( `email`, `password`) VALUES ('$email','$hash')";
			$query = mysqli_query($connect, $insert);
				if ($query == TRUE) {
					header('location: ../admin/register-admin.php?resp=1');
				}
				else{
					header('location: ../admin/register-admin.php?resp=2');
				}
		}
?>