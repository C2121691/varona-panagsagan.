<?php 
	include '../actions/connect_db.php';

	$title = $_POST['title'];
	$id = $_POST['id'];
	$description = $_POST['description'];
	$price = $_POST['price'];


			$insert = "UPDATE `tbl_products` SET `title`='$title',`description`='$description',`price`='$price' WHERE prod_id = $id ";
			$query = mysqli_query($connect, $insert);

				if ($query == 1) {
					header('location:products.php?resp=0');
				}else{
					header('location:products.php?resp=1');
				}
			
		


	

?>