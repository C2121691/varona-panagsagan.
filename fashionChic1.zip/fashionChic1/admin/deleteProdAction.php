<?php
	include '../actions/connect_db.php';

	$id = $_GET['id'];

	$sql = "DELETE FROM `tbl_products` WHERE prod_id = '$id' ";
	$query = mysqli_query($connect, $sql);

		if ($query == 1) {
			header('location:products.php?resp=0');
		}else{
			header('location:products.php?resp=1');
		}
?>