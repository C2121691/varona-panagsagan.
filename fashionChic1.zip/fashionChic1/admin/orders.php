<?php include '../actions/sessions.php'; ?>
<?php include '../actions/connect_db.php'; ?>

<!DOCTYPE html>
<html>
  <head>
    <title>Dashboard  </title>
    <meta charset="utf-8">
    <meta name="robots" content="noindex">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.5">
    <link rel="stylesheet" href="css/styles.css">
  </head>
  <body>
    <!-- (A) SIDEBAR -->
    <div id="pgside">
      <!-- (A1) BRANDING OR USER -->
      <!-- LINK TO DASHBOARD OR LOGOUT -->
      <div id="pguser">
        <img src="css/userLogo.png">
        <i class="txt"><?=$userz?></i>
      </div>

      <!-- (A2) MENU ITEMS -->
      <a href="index.php" class="">
        <i class="txt">Add Products</i>
      </a>
      <a href="products.php" class="">
        <i class="txt">Products</i>
      </a>
      <a href="orders.php" class="current">
        <i class="txt">Orders</i>
      </a>
      <a href="register-admin.php">
        <i class="txt">Add User</i>
      </a>
    </div>

    <!-- (B) MAIN -->
    <main id="pgmain">
      <h2 style="float:left">Orders Table</h2>
      <a class="logoutBtn" href="../actions/logout.php?logout"><p>Logout</p></a>

      <div class="table">
        <table id="customers">
			  	<thead>
			  		<th>Order ID</th>
			  		<th>Fullname</th>
			  		<th>Address</th>
			  		<th>Item</th>
			  		<th>Photo</th>
			  		
			  		<th>Price</th>
			  		<th>Method</th>
			  		<th>Status</th>
			  		<th>Action</th>

			  	</thead>
			  	<?php 
			  	$select = "SELECT * FROM tbl_orders ts JOIN tbl_products tp ON ts.prod_id = tp.prod_id ORDER BY ts.dateAdded DESC";
			  	$query = mysqli_query($connect, $select);
			  		while($row = $query->fetch_assoc()){ ?>
			  			<tr>
			  				<td><?=$row['order_id']?></td>
			  				<td><?=$row['fullname']?></td>
			  				<td><?=$row['address']?></td>
			  				<td><?=$row['title']?></td>
			  				<td> <img src="images/<?=$row['photo']?>" width="100"> </td>
			  				<td><?=$row['price']?></td>
			  				<td><?=$row['method']?></td>
			  				<td><?=$row['status']?></td>
			  				<td><a href="approvedOrder.php?id=<?=$row['order_id']?>" class="btn" style="background: green;">Approved</a></td>
			  			</tr>
			  	<?php	}
			  	 ?>
				</table>
      </div>
    </main>
  </body>
</html>