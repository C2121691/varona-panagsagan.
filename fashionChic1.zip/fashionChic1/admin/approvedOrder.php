<?php
include "../actions/connect_db.php";

$id = $_GET['id'];

	$update = "UPDATE tbl_orders SET status='Shipped' WHERE order_id = '$id' ";
	$query = mysqli_query($connect, $update);

		if ($query == 1) {
					header('location:orders.php?resp=0');
				}else{
					header('location:orders.php?resp=1');
				}
?>