<?php include 'actions/sessions.php'; ?>
<?php include 'actions/connect_db.php'; ?>

<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="css/homeCss.css">
<title>Fashion Chic Online Shop</title>
</head>
<body>

<div class="grid-container">
  <div class="headerCart">
    <ul>
      <li style="float: left;padding: 5px; color: white; font-size: 25px;"><a href="home.php"> Fashion Chic Online Shop</a></li>
      
       <li style="float: right;"><a href="actions/logout.php?logout">Logout</a></li>
        <li style="float: right;"><a href="#"><?=$userz?></a></li>
        <?php 
        $sselect = "SELECT COUNT(cart_id) as counts FROM tbl_cart WHERE user_id = '$userId' AND status = 0";
        $query = mysqli_query($connect, $sselect);
          $row = mysqli_fetch_assoc($query);
        ?>
        <li  style="float:right;"><a href="orders.php" >Orders</a></li>
        <li style="float: right;"><a href="cart.php">Cart (<?=$row['counts']?>)</a></li>
    </ul>
  </div>

  <div class="mainCart" style="margin:0 auto">
    
    <div class="table">
        <table id="customers">
          <thead>
            <th>Order ID</th>
            <th>Fullname</th>
            <th>Address</th>
            <th>Item</th>
            <th>Photo</th>
            <th>Price</th>
            <th>Method</th>
            <th>Status</th>

          </thead>
          <?php 
          $select = "SELECT * FROM tbl_orders ts JOIN tbl_products tp ON ts.prod_id = tp.prod_id ORDER BY ts.dateAdded DESC";
          $query = mysqli_query($connect, $select);
            while($row = $query->fetch_assoc()){ ?>
              <tr>
                <td><?=$row['order_id']?></td>
                <td><?=$row['fullname']?></td>
                <td><?=$row['address']?></td>
                <td><?=$row['title']?></td>
                <td> <img src="admin/images/<?=$row['photo']?>" width="100"> </td>
                <td>P <?=$row['price']?>.00</td>
                <td><?=$row['method']?></td>
                <td><?=$row['status']?></td>
              </tr>
          <?php }
           ?>
        </table>
      </div>

   
      
  </div>

  <div class="footer">
    <p>© 2023 All Rights Reserved. By Fashion Chic</p>
  </div>

</div>
</body>
</html>

