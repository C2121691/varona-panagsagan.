<?php 
	include 'connect_db.php';
	session_start();

	$user = $_POST['email'];
	$password = $_POST['password'];
	$hash = md5($password);
	$sql = "SELECT * FROM tbl_users WHERE email = '$user' AND password = '$hash' LIMIT 1";
	$query = mysqli_query($connect, $sql);

	if(mysqli_num_rows($query)>0){
		while ($row = $query->fetch_assoc()) {
			$_SESSION['email']=$row['email'];
			$role = $row['role'];
				if ($role == 'admin') {
					header('location:../admin/index.php');
				}else{
					header('location:../home.php');
				}
			
		}
	}else{
		header('location:../index.php?resp=0');
		//echo 'error'.$sql.'into'.$connect->error;
	}
		
	
		
	



 ?> 