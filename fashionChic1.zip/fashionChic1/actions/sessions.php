<?php
 include 'connect_db.php';
    session_start();

    if(!isset($_SESSION['email']))
    {	
    	header('location: index.php');
    	exit;
    }else{
    	$userz = $_SESSION['email'];
        $sql = "SELECT * FROM tbl_users WHERE email = '$userz' ";
        $query = mysqli_query($connect, $sql);
            while($row = $query->fetch_assoc()){
                $userId = $row['userId'];
            }
    }
    
    	?>